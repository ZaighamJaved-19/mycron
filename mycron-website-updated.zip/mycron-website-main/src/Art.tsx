// Brand-matched illustrations (pure SVG, no external files) for MYCRON.
// Palette comes from the logo sheet: deep forest, mid green, sage, ivory + copper accent.
const C = {
  deep: '#143426', forest: '#244b3c', mid: '#3c6a54', sage: '#a4b4a5', mist: '#dbe3d8',
  paper: '#f5f3ee', white: '#ffffff', copper: '#b17c56', ink: '#202321',
}

function Backdrop({ w, h, tone = 'light' }: { w: number; h: number; tone?: 'light' | 'dark' }) {
  const dark = tone === 'dark'
  return <>
    <defs>
      <linearGradient id={`g-${w}-${tone}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={dark ? C.forest : '#e7ece3'} />
        <stop offset="1" stopColor={dark ? C.deep : '#cfdacb'} />
      </linearGradient>
    </defs>
    <rect width={w} height={h} fill={`url(#g-${w}-${tone})`} />
    <path d={`M0 0 L${w * 0.42} 0 L0 ${h * 0.5} Z`} fill={dark ? '#ffffff' : C.forest} opacity={dark ? 0.06 : 0.1} />
    <path d={`M${w} ${h} L${w * 0.55} ${h} L${w} ${h * 0.45} Z`} fill={dark ? '#ffffff' : C.forest} opacity={dark ? 0.07 : 0.14} />
  </>
}

const Line = ({ x, y, w, c = C.sage, h = 8, o = 1 }: { x: number; y: number; w: number; c?: string; h?: number; o?: number }) =>
  <rect x={x} y={y} width={w} height={h} rx={h / 2} fill={c} opacity={o} />

function Window({ x, y, w, h, fill = C.white, bar = C.mist, children }: { x: number; y: number; w: number; h: number; fill?: string; bar?: string; children?: React.ReactNode }) {
  return <g>
    <rect x={x} y={y + 8} width={w} height={h} rx="10" fill="#0e241a" opacity=".16" />
    <rect x={x} y={y} width={w} height={h} rx="10" fill={fill} />
    <path d={`M${x} ${y + 10} a10 10 0 0 1 10 -10 h${w - 20} a10 10 0 0 1 10 10 v14 h-${w} z`} fill={bar} />
    <circle cx={x + 16} cy={y + 12} r="3.5" fill={C.copper} /><circle cx={x + 29} cy={y + 12} r="3.5" fill={C.sage} /><circle cx={x + 42} cy={y + 12} r="3.5" fill={C.mid} />
    {children}
  </g>
}

export function HeroArt() {
  const code = [[0, 120, C.sage], [20, 170, C.mid], [20, 110, C.copper], [40, 190, C.sage], [40, 90, C.mid], [20, 60, C.copper], [0, 140, C.sage], [20, 200, C.mid], [20, 130, C.sage], [0, 80, C.copper]] as const
  return <svg viewBox="0 0 520 560" role="img" aria-label="Illustration of a website, code editor, AI assistant and analytics dashboard">
    <Backdrop w={520} h={560} tone="dark" />
    {/* code editor */}
    <Window x={44} y={70} w={330} h={270} fill={C.deep} bar="#0f2a1f">
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => <text key={i} x={62} y={118 + i * 21} fontSize="9" fill={C.mid} fontFamily="monospace">{i + 1}</text>)}
      {code.map(([ind, len, col], i) => <Line key={i} x={90 + ind} y={112 + i * 21} w={len} c={col} h={7} o={0.9} />)}
    </Window>
    {/* website preview */}
    <Window x={190} y={205} w={290} h={215}>
      <rect x={190} y={229} width={290} height={34} fill={C.paper} />
      <rect x={206} y={240} width={18} height={12} fill={C.forest} />
      <Line x={236} y={243} w={46} c={C.forest} h={6} /><Line x={380} y={243} w={24} h={6} /><Line x={412} y={243} w={24} h={6} />
      <rect x={440} y={238} width={26} height={14} rx="2" fill={C.forest} />
      <Line x={210} y={285} w={150} c={C.ink} h={12} /><Line x={210} y={305} w={110} c={C.forest} h={12} />
      <Line x={210} y={332} w={170} c={C.sage} h={6} /><Line x={210} y={346} w={140} c={C.sage} h={6} />
      <rect x={210} y={366} width={64} height={20} fill={C.forest} />
      <rect x={380} y={282} width={84} height={104} rx="4" fill={C.mist} />
      <path d="M380 386 L408 340 L430 364 L446 330 L464 386 Z" fill={C.mid} />
      <circle cx="446" cy="308" r="9" fill={C.copper} />
    </Window>
    {/* AI chat bubble */}
    <g>
      <rect x={52} y={372} width={170} height={74} rx="14" fill={C.paper} />
      <path d="M78 446 l-4 18 l22 -18 z" fill={C.paper} />
      <circle cx={78} cy={398} r="11" fill={C.forest} />
      <path d="M72 398 l4 4 l8 -9" stroke={C.paper} strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <Line x={98} y={391} w={96} c={C.forest} h={6} /><Line x={98} y={403} w={70} c={C.sage} h={6} />
      <Line x={68} y={424} w={140} c={C.mist} h={6} /><Line x={68} y={435} w={96} c={C.mist} h={6} />
    </g>
    {/* analytics card */}
    <g>
      <rect x={338} y={58} width={140} height={110} rx="10" fill={C.paper} />
      <Line x={354} y={74} w={50} c={C.forest} h={6} />
      {[28, 46, 36, 62, 52, 78].map((v, i) => <rect key={i} x={354 + i * 20} y={150 - v} width={12} height={v} rx="2" fill={i === 5 ? C.copper : i % 2 ? C.mid : C.sage} />)}
    </g>
    {/* network nodes */}
    <g stroke={C.sage} strokeWidth="1.2" opacity=".55" fill="none">
      <path d="M440 470 L400 500 L330 482 L290 520" /><path d="M400 500 L440 530" />
    </g>
    {[[440, 470, 6], [400, 500, 5], [330, 482, 6], [290, 520, 4], [440, 530, 4]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={i === 0 ? C.copper : C.sage} />)}
  </svg>
}

export type ArtKind = 'web' | 'ai' | 'software' | 'automation' | 'design' | 'cloud'

export function ServiceArt({ kind }: { kind: ArtKind }) {
  const W = 640, H = 480
  return <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
    <Backdrop w={W} h={H} />
    {kind === 'web' && <>
      <Window x={80} y={70} w={400} h={290}>
        <rect x={80} y={94} width={400} height={40} fill={C.paper} />
        <rect x={98} y={106} width={22} height={16} fill={C.forest} />
        <Line x={134} y={110} w={54} c={C.forest} h={7} />
        {[330, 366, 402].map(x => <Line key={x} x={x} y={111} w={26} h={6} />)}
        <rect x={436} y={105} width={30} height={18} rx="2" fill={C.forest} />
        <Line x={102} y={160} w={190} c={C.ink} h={16} /><Line x={102} y={186} w={140} c={C.forest} h={16} />
        <Line x={102} y={222} w={210} c={C.sage} h={7} /><Line x={102} y={238} w={176} c={C.sage} h={7} />
        <rect x={102} y={262} width={82} height={26} fill={C.forest} /><rect x={194} y={262} width={82} height={26} fill="none" stroke={C.forest} />
        <rect x={330} y={150} width={128} height={150} rx="4" fill={C.mist} />
        <path d="M330 300 L372 236 L404 276 L430 226 L458 300 Z" fill={C.mid} /><circle cx="424" cy="186" r="12" fill={C.copper} />
        {[102, 232, 362].map(x => <g key={x}><rect x={x} y={312} width={110} height={36} rx="3" fill={C.paper} /><Line x={x + 10} y={324} w={50} c={C.forest} h={6} /><Line x={x + 10} y={335} w={70} c={C.sage} h={5} /></g>)}
      </Window>
      <g>
        <rect x={430} y={190} width={150} height={250} rx="20" fill={C.deep} />
        <rect x={440} y={206} width={130} height={218} rx="10" fill={C.paper} />
        <Line x={452} y={222} w={70} c={C.ink} h={10} /><Line x={452} y={240} w={96} c={C.forest} h={10} />
        <rect x={452} y={266} width={106} height={62} rx="4" fill={C.mist} /><path d="M452 328 L484 292 L508 316 L530 282 L558 328 Z" fill={C.mid} />
        <rect x={452} y={342} width={52} height={18} fill={C.forest} />
        <Line x={452} y={374} w={100} c={C.sage} h={6} /><Line x={452} y={386} w={72} c={C.sage} h={6} />
      </g>
    </>}
    {kind === 'ai' && <>
      <g stroke={C.mid} strokeWidth="1.6" opacity=".6" fill="none">
        {[[320, 240, 140, 120], [320, 240, 500, 110], [320, 240, 120, 340], [320, 240, 520, 350], [320, 240, 320, 70], [320, 240, 320, 420], [140, 120, 320, 70], [500, 110, 320, 70], [120, 340, 320, 420], [520, 350, 320, 420]].map(([a, b, c, d], i) => <path key={i} d={`M${a} ${b} L${c} ${d}`} />)}
      </g>
      {[[140, 120, 18], [500, 110, 22], [120, 340, 16], [520, 350, 20], [320, 70, 15], [320, 420, 17]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill={i % 3 === 0 ? C.sage : C.mist} stroke={C.forest} strokeWidth="2" />)}
      <circle cx="320" cy="240" r="68" fill={C.forest} /><circle cx="320" cy="240" r="86" fill="none" stroke={C.forest} strokeWidth="1.5" strokeDasharray="4 7" />
      <path d="M284 240 h14 l10 -26 l18 52 l10 -26 h22" stroke={C.paper} strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="500" cy="110" r="7" fill={C.copper} />
      <g><rect x={36} y={196} width={118} height={52} rx="12" fill={C.paper} /><Line x={50} y={212} w={74} c={C.forest} h={6} /><Line x={50} y={226} w={52} c={C.sage} h={6} /></g>
      <g><rect x={486} y={226} width={118} height={52} rx="12" fill={C.forest} /><Line x={500} y={242} w={80} c={C.paper} h={6} /><Line x={500} y={256} w={58} c={C.sage} h={6} /></g>
    </>}
    {kind === 'software' && <>
      <Window x={70} y={60} w={500} h={340} fill={C.deep} bar="#0f2a1f">
        <rect x={70} y={84} width={118} height={316} fill="#0f2a1f" />
        {[0, 1, 2, 3, 4, 5].map(i => <Line key={i} x={86 + (i % 3 === 1 ? 12 : 0)} y={104 + i * 24} w={70 - (i % 2) * 18} c={i === 2 ? C.copper : C.mid} h={7} />)}
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(i => {
          const ind = [0, 24, 24, 48, 48, 24, 0, 24, 48, 48, 24, 0][i]; const len = [90, 150, 110, 200, 120, 70, 100, 170, 130, 90, 60, 80][i]
          return <g key={i}><text x={206} y={112 + i * 22} fontSize="9" fill={C.mid} fontFamily="monospace">{i + 1}</text><Line x={232 + ind} y={105 + i * 22} w={len} c={[C.sage, C.mid, C.copper, C.mist][i % 4]} h={7} o={0.9} /></g>
        })}
      </Window>
      <g><rect x={430} y={300} width={170} height={110} rx="10" fill={C.paper} /><Line x={448} y={318} w={60} c={C.forest} h={6} />
        {[0, 1, 2].map(i => <g key={i}><rect x={448} y={338 + i * 22} width={10} height={10} rx="2" fill={i === 0 ? C.copper : C.mid} /><Line x={466} y={340 + i * 22} w={100 - i * 18} c={C.sage} h={6} /></g>)}</g>
    </>}
    {kind === 'automation' && <>
      <g stroke={C.forest} strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M200 160 H300 V240 H380" /><path d="M300 240 V330 H380" /><path d="M200 160 H100" opacity="0" />
        <path d="M480 240 H540" /><path d="M480 330 H540" /><path d="M368 233 l12 7 l-12 7" /><path d="M368 323 l12 7 l-12 7" />
      </g>
      <g><rect x={70} y={120} width={130} height={80} rx="10" fill={C.forest} /><circle cx="96" cy="160" r="12" fill={C.copper} /><Line x={118} y={150} w={60} c={C.paper} h={7} /><Line x={118} y={166} w={44} c={C.sage} h={6} /></g>
      <g><rect x={380} y={200} width={100} height={80} rx="10" fill={C.paper} stroke={C.forest} strokeWidth="2" /><Line x={396} y={226} w={60} c={C.forest} h={7} /><Line x={396} y={244} w={44} c={C.sage} h={6} /></g>
      <g><rect x={380} y={290} width={100} height={80} rx="10" fill={C.paper} stroke={C.forest} strokeWidth="2" /><Line x={396} y={316} w={60} c={C.forest} h={7} /><Line x={396} y={334} w={44} c={C.sage} h={6} /></g>
      <g fill={C.mid}><rect x={540} y={214} width={56} height={52} rx="8" /><rect x={540} y={304} width={56} height={52} rx="8" /></g>
      <path d="M556 242 l8 8 l16 -18 M556 332 l8 8 l16 -18" stroke={C.paper} strokeWidth="3.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="140" cy="340" r="34" fill="none" stroke={C.forest} strokeWidth="2.5" strokeDasharray="5 6" /><circle cx="140" cy="340" r="12" fill={C.forest} />
    </>}
    {kind === 'design' && <>
      <rect x={70} y={60} width={380} height={360} rx="6" fill={C.paper} stroke={C.sage} strokeDasharray="5 6" />
      <rect x={110} y={100} width={150} height={280} rx="16" fill={C.white} stroke={C.forest} strokeWidth="2" />
      <Line x={128} y={124} w={70} c={C.ink} h={10} /><rect x={128} y={150} width={114} height={80} rx="6" fill={C.mist} /><path d="M128 230 L160 190 L184 214 L206 180 L242 230 Z" fill={C.mid} />
      <Line x={128} y={248} w={100} c={C.sage} h={6} /><Line x={128} y={260} w={74} c={C.sage} h={6} /><rect x={128} y={290} width={114} height={30} rx="4" fill={C.forest} />
      <rect x={290} y={100} width={130} height={130} rx="8" fill={C.white} stroke={C.forest} strokeWidth="2" />
      <circle cx="355" cy="165" r="38" fill="none" stroke={C.mid} strokeWidth="2" /><rect x={327} y={137} width={56} height={56} fill="none" stroke={C.copper} strokeWidth="2" />
      <rect x={290} y={250} width={130} height={130} rx="8" fill={C.white} stroke={C.sage} />
      <Line x={306} y={270} w={60} c={C.forest} h={8} /><Line x={306} y={290} w={96} c={C.sage} h={6} /><Line x={306} y={302} w={80} c={C.sage} h={6} />
      {[C.deep, C.forest, C.mid, C.sage, C.copper].map((c, i) => <circle key={i} cx={306 + i * 24} cy={350} r="10" fill={c} />)}
      <g transform="translate(470 120)"><rect width="130" height="230" rx="8" fill={C.deep} />
        {[C.deep, C.forest, C.mid, C.sage, C.mist].map((c, i) => <rect key={i} x="14" y={16 + i * 34} width="102" height="26" rx="4" fill={c} stroke="#ffffff22" />)}
        <Line x={14} y={196} w={70} c={C.copper} h={8} /></g>
      <path d="M392 300 l-8 -34 l24 18 l-10 4 l10 22 l-8 4 l-10 -22 z" fill={C.ink} stroke={C.paper} strokeWidth="1.5" transform="translate(30 -20)" />
    </>}
    {kind === 'cloud' && <>
      <path d="M170 250 a64 64 0 0 1 24 -124 a92 92 0 0 1 176 -12 a76 76 0 0 1 80 136 z" fill={C.paper} stroke={C.forest} strokeWidth="2.5" transform="translate(30 20)" />
      <g transform="translate(250 180)">
        {[0, 1, 2].map(i => <g key={i}><rect x="0" y={i * 52} width="150" height="42" rx="6" fill={C.forest} /><circle cx="22" cy={21 + i * 52} r="5" fill={i === 0 ? C.copper : C.sage} /><Line x={40} y={17 + i * 52} w={70} c={C.sage} h={6} o={0.9} /><Line x={40} y={28 + i * 52} w={44} c={C.mid} h={5} /></g>)}
      </g>
      <path d="M180 400 V350 M180 350 l-14 14 M180 350 l14 14" stroke={C.forest} strokeWidth="3.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <g stroke={C.forest} strokeWidth="2" fill="none" transform="translate(470 330)"><circle cx="50" cy="50" r="46" fill={C.mist} /><ellipse cx="50" cy="50" rx="20" ry="46" /><path d="M4 50 H96 M10 28 H90 M10 72 H90" /></g>
      <path d="M470 380 C 440 380 430 340 400 330" stroke={C.copper} strokeWidth="2.5" fill="none" strokeDasharray="5 6" />
      <circle cx="400" cy="330" r="6" fill={C.copper} />
    </>}
  </svg>
}
