import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import {
  ArrowUpRight, Check, Menu, X, Mail, MessageCircle,
  Globe2, Code2, BrainCircuit, Workflow, PenTool, CloudCog, ArrowRight,
} from 'lucide-react'
import { Link, BrowserRouter, Routes, Route, useLocation, useParams } from 'react-router-dom'
import { HeroArt } from './Art'
import type { ArtKind } from './Art'
import './App.css'

const config = {
  name: 'MYCRON',
  email: 'hello@mycron.tech',
  whatsapp: '923001234567',
  phoneLabel: '+92 300 1234567',
  location: 'Rawalpindi, Pakistan',
}
const currentYear = new Date().getFullYear()

const services = [
  { n: '01', slug: 'website-development', art: 'web' as ArtKind, title: 'Website Development', image: 'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1400&q=85', icon: Globe2, desc: 'Professional digital experiences that communicate your brand, establish credibility, and help customers connect with your business.', items: ['Corporate websites', 'Custom landing pages', 'E-commerce experiences', 'Responsive development'] },
  { n: '02', slug: 'ai-intelligent-solutions', art: 'ai' as ArtKind, title: 'AI & Intelligent Solutions', image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1400&q=85', icon: BrainCircuit, desc: 'Practical applications of artificial intelligence to improve workflows, access information, and enhance digital experiences.', items: ['AI-powered assistants', 'Intelligent retrieval', 'Document workflows', 'AI application development'] },
  { n: '03', slug: 'software-development', art: 'software' as ArtKind, title: 'Software Development', image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1400&q=85', icon: Code2, desc: 'Custom software solutions designed to address operational challenges, support business processes, and provide useful digital functionality.', items: ['Business applications', 'Internal management systems', 'Database solutions', 'API integrations'] },
  { n: '04', slug: 'business-automation', art: 'automation' as ArtKind, title: 'Business Automation', image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1400&q=85', icon: Workflow, desc: 'Reduce repetitive work and improve operational efficiency through carefully designed digital workflows and automation.', items: ['Workflow automation', 'Data synchronization', 'System integrations', 'Automated reporting'] },
  { n: '05', slug: 'ui-ux-digital-design', art: 'design' as ArtKind, title: 'UI/UX & Digital Design', image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=1400&q=85', icon: PenTool, desc: 'Intuitive digital experiences that combine strong visual communication with practical usability.', items: ['Website UI/UX', 'Design systems', 'User journey planning', 'Website redesign'] },
  { n: '06', slug: 'cloud-deployment', art: 'cloud' as ArtKind, title: 'Cloud & Deployment', image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1400&q=85', icon: CloudCog, desc: 'Take digital products from development to deployment with practical hosting, configuration, and technical support.', items: ['Website deployment', 'Domain and DNS setup', 'Cloud deployment', 'Technical maintenance'] },
]

const projects = [
  { n: '01', title: 'Business Website', category: 'Corporate & Professional', desc: 'A refined corporate website concept focused on brand communication, service presentation, and customer inquiries.', image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=85' },
  { n: '02', title: 'Restaurant Digital Experience', category: 'Hospitality', desc: 'A modern restaurant website concept with menu presentation, location details, and customer communication.', image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85' },
  { n: '03', title: 'Educational Platform', category: 'Education & Technology', desc: 'A learning platform concept designed to organize educational information and improve access to digital resources.', image: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=85' },
  { n: '04', title: 'AI Business Assistant', category: 'Artificial Intelligence', desc: 'An AI-powered assistant concept demonstrating how intelligent systems can help businesses access information and automate workflows.', image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=85' },
]

function Logo({ light = false }: { light?: boolean }) {
  return <Link to="/" className="logo" aria-label="Mycron home"><img src={light ? '/brand/mycron-logo-light.png' : '/brand/mycron-logo.png'} alt="Mycron" width="986" height="215" /></Link>
}

function ScrollManager() {
  const { pathname, hash } = useLocation()
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(decodeURIComponent(hash.slice(1)))
      if (el) { setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60); return }
    }
    window.scrollTo(0, 0)
  }, [pathname, hash])
  return null
}

function Header() {
  const [open, setOpen] = useState(false)
  const location = useLocation()
  const links = [['/', 'Home'], ['/services', 'Services'], ['/industries', 'Industries'], ['/work', 'Our Work'], ['/about', 'About']]
  return <header className="site-header">
    <div className="container nav-wrap"><Logo />
      <nav className={`nav-links ${open ? 'open' : ''}`}>{links.map(([href, label]) => <Link key={href} className={location.pathname === href ? 'active' : ''} onClick={() => setOpen(false)} to={href}>{label}</Link>)}<Link className="nav-cta" onClick={() => setOpen(false)} to="/contact">Discuss a Project <ArrowUpRight size={15} /></Link></nav>
      <button className="menu-toggle" aria-label="Toggle menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
    </div>
  </header>
}

function Footer() {
  return <footer className="footer"><div className="container">
    <div className="footer-top"><div><Logo light /><p className="footer-lead">Technology, intelligent systems, and digital solutions built around business ambitions.</p></div><div className="footer-col"><span className="footer-label">Explore</span><Link to="/services">Services</Link><Link to="/industries">Industries</Link><Link to="/work">Our Work</Link><Link to="/about">About</Link></div><div className="footer-col"><span className="footer-label">Capabilities</span>{services.slice(0, 5).map(s => <Link to={`/services#${s.slug}`} key={s.title}>{s.title}</Link>)}</div><div className="footer-col"><span className="footer-label">Connect</span><a href={`mailto:${config.email}`}>{config.email}</a><a href={`https://wa.me/${config.whatsapp}`} target="_blank" rel="noreferrer">WhatsApp</a><span>{config.location}</span></div></div>
    <div className="footer-bottom"><span>© {currentYear} MYCRON. All rights reserved.</span><span><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms of Service</Link></span></div>
  </div></footer>
}

function PageShell({ children }: { children: React.ReactNode }) { return <><Header />{children}<Footer /></> }
function Eyebrow({ children }: { children: React.ReactNode }) { return <div className="eyebrow"><span />{children}</div> }
function Button({ children, to = '/contact', secondary = false }: { children: React.ReactNode; to?: string; secondary?: boolean }) { return <Link className={`button ${secondary ? 'button-secondary' : ''}`} to={to}>{children}<ArrowUpRight size={16} /></Link> }

function Home() {
  return <PageShell><main>
    <section className="hero"><div className="container hero-grid"><div className="hero-copy"><Eyebrow>Independent technology & digital solutions</Eyebrow><h1>Technology that moves <em>business forward.</em></h1><p className="hero-text">MYCRON helps businesses turn ambitious ideas into practical digital solutions through intelligent technology, thoughtful engineering, and purposeful design.</p><div className="hero-actions"><Button>Discuss Your Project</Button><Button to="/services" secondary>Explore Capabilities</Button></div><div className="value-list"><span>Built around your business</span><span>Designed for real-world use</span><span>Engineered for growth</span></div></div><div className="hero-visual"><HeroArt /><div className="visual-note">01 / Digital foundations<br /><strong>Engineering what's next.</strong></div></div></div></section>
    <section className="section intro"><div className="container split"><div><Eyebrow>What we do</Eyebrow><h2>Technology is only valuable when it solves the right problem.</h2></div><div className="intro-side"><p>Every business has different challenges. We focus on understanding those challenges and creating digital solutions that improve how businesses operate, communicate, and grow.</p><Link className="text-link" to="/about">Discover MYCRON <ArrowRight size={16} /></Link></div></div></section>
    <ServicesPreview />
    <section className="dark-band"><div className="container dark-grid"><div><Eyebrow>Our approach</Eyebrow><h2>Built on clarity.<br /><em>Driven by execution.</em></h2></div><div><p>Good technology begins with understanding the problem. Our approach combines practical thinking, careful execution, and a focus on outcomes that matter to your business.</p><Link className="text-link light-link" to="/about">How we work <ArrowRight size={16} /></Link></div></div></section>
    <WorkPreview />
    <CTA />
  </main></PageShell>
}

function ServicesPreview() {
  return <section className="section services-preview"><div className="container"><div className="section-head"><div><Eyebrow>Our capabilities</Eyebrow><h2>Practical technology.<br /><em>Thoughtful execution.</em></h2></div><p>From establishing your digital presence to developing intelligent business systems, we deliver solutions designed around real requirements.</p></div><div className="service-list">{services.map(s => { const Icon = s.icon; return <Link to={`/services#${s.slug}`} className="service-row" key={s.n}><span className="service-number">{s.n}</span><Icon className="service-icon" size={27} strokeWidth={1.4} /><h3>{s.title}</h3><span className="service-arrow"><ArrowUpRight size={19} /></span></Link> })}</div></div></section>
}

function WorkPreview() {
  return <section className="section work-preview"><div className="container"><div className="section-head"><div><Eyebrow>Selected work</Eyebrow><h2>Designed with purpose.<br /><em>Built with precision.</em></h2></div><Button to="/work" secondary>View all work</Button></div><div className="work-grid">{projects.slice(0, 3).map((p, i) => <Link to="/work" className={`project-card project-${i}`} key={p.title}><div className="project-image"><img src={p.image} alt={`${p.title} concept project`} /><span>Concept project</span></div><div className="project-meta"><div><small>{p.category}</small><h3>{p.title}</h3></div><ArrowUpRight size={19} /></div></Link>)}</div></div></section>
}

function CTA() { return <section className="cta"><div className="container cta-inner"><Eyebrow>Start a conversation</Eyebrow><h2>Let's build something that<br /><em>moves your business forward.</em></h2><p>Tell us where you want to go. We'll help you explore the technology to get there.</p><Button>Discuss Your Project</Button></div></section> }

function Services() { return <PageShell><PageIntro eyebrow="Our capabilities" title={<>Technology with a <em>purpose.</em></>} description="From digital foundations to intelligent systems, we build practical solutions that help ambitious businesses move forward." /><section className="section"><div className="container service-detail-list">{services.map(s => { const Icon = s.icon; return <article className="service-detail" id={s.slug} key={s.n}><div className="service-detail-media"><img src={s.image} alt={`${s.title} in action`} loading="lazy" /><span className="service-badge"><Icon size={18} strokeWidth={1.5} />{s.n}</span></div><div className="service-detail-body"><h2>{s.title}</h2><p>{s.desc}</p><div className="capabilities">{s.items.map(item => <span key={item}><Check size={14} />{item}</span>)}</div><Link className="text-link" to={`/contact?service=${encodeURIComponent(s.title)}`}>Discuss this service <ArrowRight size={16} /></Link></div></article> })}</div></section><CTA /></PageShell> }

function PageIntro({ eyebrow, title, description }: { eyebrow: string; title: React.ReactNode; description: string }) { return <section className="page-intro"><div className="container"><Eyebrow>{eyebrow}</Eyebrow><h1>{title}</h1><p>{description}</p></div></section> }

const industries = [
  { n: '01', slug: 'business-professional-services', title: 'Business & Professional Services', desc: 'Professional digital identities, business websites, and customer inquiry systems.', image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1600&q=85', lead: 'Turn expertise into a clear, credible digital experience.', impact: 'MYCRON helps consultants, agencies, and professional firms explain complex offerings, capture better inquiries, and create digital workflows that give teams more time for client work.', outcomes: ['A sharper digital presence that builds trust before the first conversation', 'Structured inquiry flows that qualify prospects and reduce follow-up friction', 'Connected internal tools for proposals, reporting, and client communication'], focus: ['Website strategy and development', 'Lead capture and inquiry automation', 'Client portals and internal systems'] },
  { n: '02', slug: 'education', title: 'Education', desc: 'Educational platforms, learning-related applications, and digital information systems.', image: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1600&q=85', lead: 'Make learning easier to access, navigate, and act on.', impact: 'From schools to training providers, MYCRON creates student-friendly platforms that organize information, support learning journeys, and reduce administrative overhead.', outcomes: ['Clear program and admissions journeys for prospective learners', 'Learning resources that work across devices and contexts', 'Automated communication for reminders, updates, and reporting'], focus: ['Education websites and portals', 'Learning workflow automation', 'Information architecture and UX'] },
  { n: '03', slug: 'retail-ecommerce', title: 'Retail & E-commerce', desc: 'Online stores, product experiences, and digital customer journeys.', image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1600&q=85', lead: 'Create shopping experiences that move customers from interest to action.', impact: 'MYCRON helps retail teams present products clearly, remove checkout friction, and connect customer-facing experiences with the systems behind the sale.', outcomes: ['Faster, clearer paths from product discovery to purchase', 'Mobile-first storefronts that support real customer behavior', 'Connected inventory, inquiry, and marketing workflows'], focus: ['E-commerce development', 'Conversion-focused UI/UX', 'Catalog and operational integrations'] },
  { n: '04', slug: 'hospitality', title: 'Hospitality', desc: 'Restaurant websites, digital menus, reservation inquiries, and customer experiences.', image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=85', lead: 'Make every guest interaction feel considered, from discovery to booking.', impact: 'MYCRON gives restaurants, hotels, and hospitality teams digital experiences that showcase what makes them distinctive and make it simple for guests to take the next step.', outcomes: ['Beautiful, practical menus and service information', 'Reservation and inquiry journeys that work on mobile', 'Content systems teams can update without developer support'], focus: ['Hospitality websites and menus', 'Reservation inquiry flows', 'Content management and local visibility'] },
  { n: '05', slug: 'startups-entrepreneurs', title: 'Startups & Entrepreneurs', desc: 'Digital products, landing pages, MVP development, and technology foundations.', image: 'https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&w=1600&q=85', lead: 'Move from an ambitious idea to a useful first product.', impact: 'MYCRON helps founders validate ideas, communicate value, and build focused MVPs that are ready to learn from real users and grow with the business.', outcomes: ['A clear product story for customers, partners, and investors', 'Lean MVPs that test the riskiest assumptions early', 'A dependable technical foundation for the next stage'], focus: ['MVP and prototype development', 'Launch websites and landing pages', 'Product discovery and technical planning'] },
  { n: '06', slug: 'operations-enterprises', title: 'Operations & Enterprises', desc: 'Custom applications, automation, and integrated digital workflows.', image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1600&q=85', lead: 'Make complex operations more visible, connected, and reliable.', impact: 'MYCRON works with operational teams to replace disconnected manual tasks with useful software, automation, and reporting that supports better decisions.', outcomes: ['Less repetitive work through connected workflows', 'More reliable operational data and reporting', 'Systems designed around the way teams actually work'], focus: ['Custom internal applications', 'Workflow and data automation', 'Dashboards, integrations, and cloud deployment'] },
]

function Industries() { return <PageShell><PageIntro eyebrow="Who we work with" title={<>Digital solutions across <em>different industries.</em></>} description="We bring a considered technology approach to organizations at every stage of their digital journey." /><section className="section"><div className="container industry-list">{industries.map(industry => <Link className="industry-row" to={`/industries/${industry.slug}`} key={industry.n}><span className="service-number">{industry.n}</span><h2>{industry.title}</h2><p>{industry.desc}</p><ArrowUpRight size={20} /></Link>)}</div></section><section className="image-strip"><img src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1800&q=85" alt="Modern workspace architecture" /></section><CTA /></PageShell> }

function IndustryDetail() {
  const { slug } = useParams()
  const industry = industries.find(item => item.slug === slug)
  if (!industry) return <PageShell><PageIntro eyebrow="Industry" title={<>Industry <em>not found.</em></>} description="The requested industry page is not available." /><section className="section"><div className="container"><Link className="text-link" to="/industries">Back to industries <ArrowRight size={16} /></Link></div></section></PageShell>
  return <PageShell><main><section className="industry-hero"><div className="container industry-hero-grid"><div><Eyebrow>{industry.n} / {industry.title}</Eyebrow><h1>{industry.lead}</h1><p>{industry.impact}</p><Button to="/contact">Discuss your industry needs</Button></div><div className="industry-hero-image"><img src={industry.image} alt={`${industry.title} team and environment`} /></div></div></section><section className="section"><div className="container industry-detail-grid"><div><Eyebrow>Where MYCRON helps</Eyebrow><h2>Practical impact for <em>{industry.title.toLowerCase()}.</em></h2></div><div className="industry-outcomes">{industry.outcomes.map((outcome, index) => <div key={outcome}><span>0{index + 1}</span><p>{outcome}</p></div>)}</div></div></section><section className="dark-band"><div className="container industry-focus"><div><Eyebrow>Relevant capabilities</Eyebrow><h2>Technology shaped around <em>your context.</em></h2></div><div className="focus-list">{industry.focus.map(item => <div key={item}><Check size={16} />{item}</div>)}</div></div></section><section className="section industry-next"><div className="container"><Link className="text-link" to="/industries"><ArrowRight size={16} /> Explore other industries</Link><CTA /></div></section></main></PageShell>
}

function Work() { return <PageShell><PageIntro eyebrow="Selected work" title={<>Concepts built to <em>make an impact.</em></>} description="Explore demonstration projects that show how MYCRON approaches digital experiences and technology solutions. Concept projects are clearly marked." /><section className="section"><div className="container portfolio-grid">{projects.map(p => <article className="portfolio-card" key={p.title}><div className="portfolio-image"><img src={p.image} alt={`${p.title} concept project`} /><span>Concept project</span></div><div className="portfolio-copy"><small>{p.category}</small><h2>{p.title}</h2><p>{p.desc}</p><Link className="text-link" to="/contact">Discuss a similar project <ArrowRight size={16} /></Link></div></article>)}</div></section><CTA /></PageShell> }

function About() { return <PageShell><PageIntro eyebrow="About MYCRON" title={<>Building technology <em>with purpose.</em></>} description="A growing technology and digital solutions initiative helping businesses establish, improve, and expand their digital capabilities." /><section className="section about-story"><div className="container split"><div><Eyebrow>Our philosophy</Eyebrow><h2>Make things better, clearer, and more effective.</h2></div><div><p>We bring together modern web development, software engineering, intelligent technologies, and thoughtful design to create practical solutions for real-world challenges.</p><p>Whether you are building a new business, modernizing an existing operation, or exploring the possibilities of AI, MYCRON aims to help turn your ideas into useful digital experiences.</p></div></div></section><section className="dark-band"><div className="container principles"><div><Eyebrow>What guides us</Eyebrow><h2>Principles that keep<br /><em>the work honest.</em></h2></div><div className="principle-list">{['Understand before building', 'Purposeful design', 'Practical engineering', 'Transparent collaboration', 'Long-term thinking'].map((p, i) => <div key={p}><span>0{i + 1}</span><h3>{p}</h3></div>)}</div></div></section><CTA /></PageShell> }

function Contact() {
  const params = new URLSearchParams(useLocation().search)
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [service, setService] = useState(params.get('service') || '')
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError('')
    const endpoint = import.meta.env.VITE_FORM_ENDPOINT as string | undefined
    if (!endpoint) {
      setError('The inquiry endpoint is not configured yet. Please use email or WhatsApp, or configure VITE_FORM_ENDPOINT before launch.')
      return
    }
    setLoading(true)
    try {
      const response = await fetch(endpoint, { method: 'POST', headers: { Accept: 'application/json' }, body: new FormData(e.currentTarget) })
      if (!response.ok) throw new Error('Form submission failed')
      setSubmitted(true)
    } catch {
      setError('We could not submit your inquiry. Please try again or contact us directly by email or WhatsApp.')
    } finally {
      setLoading(false)
    }
  }
  return <PageShell><PageIntro eyebrow="Start a conversation" title={<>Let's discuss what <em>you're building.</em></>} description="Have an idea, a business challenge, or a digital project in mind? Tell us what you need, and let's explore how MYCRON can help." /><section className="section contact-section"><div className="container contact-grid"><div className="contact-details"><Eyebrow>Contact information</Eyebrow><h2>Good conversations<br /><em>start here.</em></h2><p>Share a few details about your project and we will get back to you with thoughtful next steps.</p><div className="contact-links"><a href={`mailto:${config.email}`}><Mail size={18} />{config.email}</a><a href={`https://wa.me/${config.whatsapp}`} target="_blank" rel="noreferrer"><MessageCircle size={18} />{config.phoneLabel}</a><span><Globe2 size={18} />{config.location} · Local & international projects</span></div></div><div className="form-wrap">{submitted ? <div className="success"><Check size={28} /><h2>Thank you.</h2><p>Your inquiry has been received. We'll be in touch soon.</p><Button to="/">Return home</Button></div> : <form onSubmit={submit}><label>Full name<input required name="name" placeholder="Your name" /></label><label>Email address<input required type="email" name="email" placeholder="you@company.com" /></label><label>Company / business name <span>(optional)</span><input name="company" placeholder="Company name" /></label><label>Service required<select required name="service" value={service} onChange={e => setService(e.target.value)}><option value="">Select a service</option>{services.map(s => <option key={s.title}>{s.title}</option>)}<option>Other</option></select></label><div className="form-two"><label>Project budget<select required name="budget"><option value="">Select budget</option><option>Under $100</option><option>$100–250</option><option>$250–500</option><option>$500–1,000</option><option>$1,000+</option><option>Not sure yet</option></select></label><label>Preferred contact<select required name="contact_method"><option>Email</option><option>WhatsApp</option><option>Either</option></select></label></div><label>Project description<textarea required name="description" rows={5} placeholder="Tell us what you are looking to build..." /></label>{error && <p className="form-error">{error}</p>}<button className="button form-submit" disabled={loading}>{loading ? 'Sending inquiry...' : 'Submit Project Inquiry'}<ArrowUpRight size={16} /></button><small className="form-note">Your details are used only to respond to this inquiry. No spam.</small></form>}</div></div></section></PageShell>
}

function Legal({ terms = false }: { terms?: boolean }) { return <PageShell><PageIntro eyebrow={terms ? 'Legal' : 'Privacy'} title={terms ? <>Terms of <em>Service.</em></> : <>Privacy <em>Policy.</em></>} description="Editable placeholder policy for the MYCRON website. Confirm legal details before publishing." /><section className="section legal"><div className="container legal-copy"><p className="legal-note">This page contains general website copy and must be reviewed for your business, jurisdiction, data practices, and third-party services before publication.</p><h2>{terms ? '1. Use of this website' : '1. Information we collect'}</h2><p>{terms ? 'MYCRON provides information about technology and digital solutions. Project scopes, pricing, timelines, and deliverables are agreed separately in writing.' : 'When you contact MYCRON, we may collect your name, email address, company details, project information, and preferred contact method so we can respond to your inquiry.'}</p><h2>{terms ? '2. Project engagements' : '2. How we use information'}</h2><p>{terms ? 'Third-party costs such as domains, hosting, APIs, subscriptions, and other services are separate unless explicitly included in an agreed scope.' : 'Information is used to communicate with you, understand project requirements, provide requested services, and improve the website. Confirm analytics, cookies, retention periods, and processors before launch.'}</p><h2>{terms ? '3. Contact' : '3. Data choices'}</h2><p>For questions about this page, contact <a href={`mailto:${config.email}`}>{config.email}</a>. Replace this placeholder with the legal business name, applicable jurisdiction, and any required notices.</p></div></section></PageShell> }

function AppRoutes() { return <Routes><Route path="/" element={<Home />} /><Route path="/services" element={<Services />} /><Route path="/industries" element={<Industries />} /><Route path="/industries/:slug" element={<IndustryDetail />} /><Route path="/work" element={<Work />} /><Route path="/about" element={<About />} /><Route path="/contact" element={<Contact />} /><Route path="/privacy" element={<Legal />} /><Route path="/terms" element={<Legal terms />} /><Route path="*" element={<Home />} /></Routes> }
export default function App() { return <BrowserRouter><ScrollManager /><AppRoutes /></BrowserRouter> }
