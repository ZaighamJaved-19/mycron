# MYCRON

Premium editorial website for MYCRON, a technology, AI, and digital solutions agency.

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

## Contact form

Set `VITE_FORM_ENDPOINT` to a real HTTPS form provider endpoint (for example Formspree, Basin, or a serverless API route). The UI intentionally shows a configuration error rather than displaying a fake success state when the endpoint is missing.

Replace the configurable business details in `src/App.tsx`: email, WhatsApp number, location, and social links. Replace `example.com` in `public/robots.txt` and `public/sitemap.xml` with the production domain.

## Production build

```bash
npm run build
npm run preview
```

For Cloudflare Pages or Netlify, use `npm run build` as the build command and `dist` as the publish directory. Add `VITE_FORM_ENDPOINT` in the hosting provider's environment variables. Configure SPA fallback/rewrite rules so routes resolve to `index.html`.

Before launch, confirm the legal business details and review the placeholder Privacy Policy and Terms of Service pages.
